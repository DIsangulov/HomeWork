// программа не вполне корректно работает, при распределении карт у каждого играка есть карты со значением null

package ru.raiffeisen.courses;

import java.util.Scanner;

public class Poker {

    public static void main(String[] args) {


        String [] suit = {" Spades "," Hearts "," Clubs "," Diamonds "}; //задаем массив из названий четырех мастей
        String [] cards = {" 2 "," 3 "," 4 "," 5 "," 6 "," 7 "," 8 "," 9 "," 10 "," J "," Q "," K "," A "}; // массив из игральных карт


        int n = suit.length * cards.length; // количество карт

        String[] initialization = new String[n]; // инициализация колоды
        for (int i = 0; i < suit.length; i++) {
            for (int j = 0; j < suit.length; j++) {
                initialization [suit.length*i + j] = cards[i] + " " + suit[j];
            }
        }

        int cardsForOnePlayer = 5; //задаем переменную с колличеством карт на одного игрока
        int numbersOfPlayers = 0; //задаем переменную игроков


        System.out.println("Добрый день, введите количество игроков");

        Scanner scanner = new Scanner(System.in);
        numbersOfPlayers = scanner.nextInt(); //вводим количество игроков

        if (numbersOfPlayers <= 1){
            System.out.println("Количество игроков не может быть меньше двух, пожалуйста повторите попытку"); //проверяем что игроков не менее 2х и не более
        }
        else if (numbersOfPlayers >= 6){
            System.out.println("Количество игроков не может быть больше шести, пожалуйста повторите попытку");
        }
        else {
            System.out.println("Количество игроков на данную раздачу составляет " + numbersOfPlayers + " человек");
        }



        for (int i = 0; i < n; i++) { //перетасовка колоды
            int r = i + (int) (Math.random() * (n-i));
            String temp = initialization[r];
            initialization[r] = initialization[i];
            initialization[i] = temp;
        }


        for (int i = 0; i < numbersOfPlayers * numbersOfPlayers; i++) { // вывод результата раздачи
            System.out.println(initialization[i]);
            if (i % numbersOfPlayers == numbersOfPlayers - 1);
        }
    }

}
