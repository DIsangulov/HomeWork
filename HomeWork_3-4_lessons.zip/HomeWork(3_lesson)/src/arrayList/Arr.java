// на данный момент не все успел сделать по этой части ДЗ
package arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Arr {
    public static void main(String[] args) {

        ArrayList <Integer> dyn = new ArrayList<>(0);
        System.out.println(dyn);

        dyn.add(4);
        dyn.add(8);
        dyn.add(15);
        dyn.add(16);
        dyn.add(23);
        dyn.add(42);
        dyn.add(108);


        for (Integer i:
                dyn) {
            System.out.print(i+" ");
        }

        dyn.clone();
        System.out.println(dyn);

        dyn.size();
        System.out.println(dyn);

        System.out.println(dyn.size());

        dyn.remove(6);
        System.out.println(dyn);

        dyn.addAll(4,Collections.singleton(5));
        System.out.println(dyn);

        dyn.set(0,10);
        System.out.println(dyn);

        int index = dyn.indexOf("3");
        System.out.println(dyn.get(index)+" числится под номером "+ index);

    }
}
