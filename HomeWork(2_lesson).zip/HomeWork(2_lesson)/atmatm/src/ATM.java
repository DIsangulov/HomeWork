import java.util.Scanner;

public class ATM {

    private static Scanner in;
    private static int balance;
    private static int anotherTransaction;

    public static void main(String[] args) {
        in = new Scanner(System.in);
        transaction();
    }

    private static void transaction(){
        int choice;
        System.out.println("Пожалуйста, выберети действие, которое вы хотите совершить");
        System.out.println("1. Выдача средств");
        System.out.println("2. Внесение средств");
        System.out.println("3. Баланс");

        choice = in.nextInt();

        switch (choice){
            case 1:
            int cashOut;
                System.out.println("Введите сумму для выдачи: ");
                cashOut = in.nextInt();
                if (cashOut > balance || cashOut == 0){
                    System.out.println("Недостаточно средств на счете\n");
                    anotherTransaction();
                } else {
                    balance = balance - cashOut;
                    System.out.println("Вам выдано " + cashOut + "остаток на счете составляет " + balance+ "\n");
                    anotherTransaction();
                }
                break;

            case 2:
            int cashIn;
                System.out.println("Введите сумму которую вы хотите внести");
                cashIn = in.nextInt();
                System.out.println("Ваш баланс пополнен на сумму " + cashIn + " и равен " + balance);
                anotherTransaction();
                break;

            case 3:
                System.out.println(balance);
                anotherTransaction();
                break;


                default:
                    System.out.println("Некорректная команда\n");
                    anotherTransaction();
                    break;
        }
    }

    private static void anotherTransaction(){
        System.out.println("Вы хотите совершить еще операцию? \nНажмите 1 чтобы совершить еще опреацию \n2 Выйти");
        anotherTransaction = in.nextInt();
        if (anotherTransaction == 1){
            transaction();
        } else if (anotherTransaction == 2){
            System.out.println("Досвидания!");
        } else {
            System.out.println("Некорректная команда\n\n");
            anotherTransaction();
        }


    }
}
