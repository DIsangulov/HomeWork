import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("Напишите слово");

        Scanner scanner = new Scanner(System.in);
        String str;

       while (true){
        str = scanner.nextLine();
        if(str.equals(args[0])) {
        System.out.println(str);
            }
            else {
            System.out.println("Значение не совпадает с аргументом");
                }

       }

    }

}


